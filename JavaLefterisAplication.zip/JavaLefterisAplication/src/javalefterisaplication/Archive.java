/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javalefterisaplication;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileWriter;
import javax.swing.JOptionPane;
public class Archive {
    
    File archive;
    
    public void crearArchive() {
        try {
            archive = new File("PhoneContacts.txt");
            if (archive.createNewFile()){
                JOptionPane.showMessageDialog(null,"Archive Create ");
            }
        } catch (Exception e) {
            System.out.println("e");
        }
    
    }
    
    public void escribirEnArchive(Persons persons) {
        try{
            FileWriter escriptura = new FileWriter(archive, true);
            escriptura.write(persons.getNombre() + "%" + persons.getCorreo() + "%" + persons.getTelefono() + "\r\n" );
            escriptura.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
}